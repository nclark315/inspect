import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const loginSchema = z.object({
        username: z.string().min(1, "Username is required"),
        password: z.string().min(1, "Password is required"),
      });

      const result = loginSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          error: "Invalid request", 
          details: result.error.format() 
        });
      }
      
      const { username, password } = result.data;
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "Invalid username or password" });
      }
      
      // Don't send the password back to the client
      const { password: _, ...userWithoutPassword } = user;
      
      res.status(200).json({
        user: userWithoutPassword,
        message: "Login successful",
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/auth/me", async (req: Request, res: Response) => {
    // This would normally check the session/token
    // For demo purposes, we'll return a mock response
    res.status(200).json({ 
      authenticated: true,
      message: "This would check if the user is authenticated" 
    });
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    // This would normally invalidate the session/token
    res.status(200).json({ message: "Logout successful" });
  });

  // API endpoints for data
  app.get("/api/buildings", (req: Request, res: Response) => {
    res.json([
      {
        id: "1",
        name: "Eastern Towers",
        address: "123 Main St, New York, NY",
        type: "Commercial",
        lastInspection: "2023-02-15",
        imageUrl: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8YnVpbGRpbmd8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60"
      },
      {
        id: "2",
        name: "Westfield Mall",
        address: "456 Broad St, Chicago, IL",
        type: "Commercial",
        lastInspection: "2023-04-10",
        imageUrl: "https://images.unsplash.com/photo-1565799557186-1fdcc8bae424?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8OHx8bWFsbHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60"
      },
      {
        id: "3",
        name: "Central Apartments",
        address: "789 Park Ave, Boston, MA",
        type: "Residential",
        lastInspection: "2023-03-22",
        imageUrl: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8YXBhcnRtZW50fGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60"
      }
    ]);
  });

  app.get("/api/categories", (req: Request, res: Response) => {
    res.json([
      {
        id: "1",
        name: "Structural",
        icon: "building-2",
        description: "Foundation, walls, roof structure",
        bgColor: "bg-blue-500/10",
        iconColor: "text-blue-500"
      },
      {
        id: "2",
        name: "Electrical",
        icon: "zap",
        description: "Wiring, outlets, fixtures, panels",
        bgColor: "bg-yellow-500/10",
        iconColor: "text-yellow-500"
      },
      {
        id: "3",
        name: "Plumbing",
        icon: "droplet",
        description: "Pipes, drains, fixtures, water heater",
        bgColor: "bg-sky-500/10",
        iconColor: "text-sky-500"
      },
      {
        id: "4",
        name: "HVAC",
        icon: "thermometer",
        description: "Heating, ventilation, air conditioning",
        bgColor: "bg-red-500/10",
        iconColor: "text-red-500"
      },
      {
        id: "5",
        name: "Safety",
        icon: "shield",
        description: "Fire alarms, sprinklers, exits",
        bgColor: "bg-green-500/10",
        iconColor: "text-green-500"
      }
    ]);
  });

  app.get("/api/components", (req: Request, res: Response) => {
    res.json([
      {
        id: "1",
        name: "Foundation",
        icon: "building-2",
        description: "Building's concrete foundation",
        lastInspection: "2023-01-15"
      },
      {
        id: "2",
        name: "Load Bearing Walls",
        icon: "square",
        description: "Main structural walls",
        lastInspection: "2023-02-10"
      },
      {
        id: "3",
        name: "Roof Structure",
        icon: "home",
        description: "Trusses and support beams",
        lastInspection: "2023-03-05"
      },
      {
        id: "4",
        name: "Columns",
        icon: "columns",
        description: "Vertical support columns",
        lastInspection: "2023-02-28"
      },
      {
        id: "5",
        name: "Floor Joists",
        icon: "maximize",
        description: "Support beams for flooring",
        lastInspection: "2023-01-20"
      }
    ]);
  });

  const httpServer = createServer(app);

  return httpServer;
}
