import { useEffect } from "react";
import { Switch, Route, useLocation, useRoute } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import SignIn from "./pages/SignIn";
import Home from "./pages/Home";
import BuildingSelection from "@/pages/BuildingSelection";
import CategorySelection from "@/pages/CategorySelection";
import ComponentSelection from "@/pages/ComponentSelection";
import PhotoUpload from "@/pages/PhotoUpload";
import DigitalTwinViewer from "@/pages/DigitalTwinViewer";
import ContractorDashboard from "@/pages/ContractorDashboard";
import NotFound from "@/pages/not-found";
import { AnimatePresence } from "framer-motion";
import { useAuthStore } from "@/store/authStore";

// Protected route component that redirects to SignIn if not authenticated
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuthStore();
  const [, navigate] = useLocation();
  
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/signin');
    }
  }, [isAuthenticated, navigate]);
  
  if (!isAuthenticated) {
    return null; // Return null while redirecting
  }
  
  return <>{children}</>;
}

// Public route that redirects to Home if already authenticated
function PublicRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuthStore();
  const [, navigate] = useLocation();
  
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);
  
  if (isAuthenticated) {
    return null; // Return null while redirecting
  }
  
  return <>{children}</>;
}

function Router() {
  const [location] = useLocation();
  const { user } = useAuthStore();
  
  // Redirect contractors to their dashboard
  const isContractorRoute = useRoute('/contractor');
  useEffect(() => {
    if (user?.role === 'contractor' && !isContractorRoute[0]) {
      // If contractor is not on the contractor page, redirect them
      const [, navigate] = useLocation();
      navigate('/contractor');
    }
  }, [user, isContractorRoute]);

  return (
    <AnimatePresence mode="wait">
      <Switch location={location} key={location}>
        {/* Public routes */}
        <Route path="/signin">
          <PublicRoute>
            <SignIn />
          </PublicRoute>
        </Route>
        
        {/* Protected routes */}
        <Route path="/">
          <ProtectedRoute>
            <Home />
          </ProtectedRoute>
        </Route>
        
        <Route path="/buildings">
          <ProtectedRoute>
            <BuildingSelection />
          </ProtectedRoute>
        </Route>
        
        <Route path="/categories">
          <ProtectedRoute>
            <CategorySelection />
          </ProtectedRoute>
        </Route>
        
        <Route path="/components">
          <ProtectedRoute>
            <ComponentSelection />
          </ProtectedRoute>
        </Route>
        
        <Route path="/inspect">
          <ProtectedRoute>
            <BuildingSelection />
          </ProtectedRoute>
        </Route>
        
        <Route path="/photo-upload">
          <ProtectedRoute>
            <PhotoUpload />
          </ProtectedRoute>
        </Route>
        
        <Route path="/digital-twin">
          <ProtectedRoute>
            <DigitalTwinViewer />
          </ProtectedRoute>
        </Route>
        
        <Route path="/contractor">
          <ProtectedRoute>
            <ContractorDashboard />
          </ProtectedRoute>
        </Route>
        
        {/* 404 route */}
        <Route>
          <NotFound />
        </Route>
      </Switch>
    </AnimatePresence>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
