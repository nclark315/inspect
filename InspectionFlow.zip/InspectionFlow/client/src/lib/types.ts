export interface Building {
  id: string;
  name: string;
  address: string;
  type: string;
  lastInspection: string;
  imageUrl: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  description: string;
  bgColor: string;
  iconColor: string;
}

export interface Component {
  id: string;
  name: string;
  icon: string;
  description: string;
  lastInspection: string;
}

export interface ProjectLead {
  id: string;
  name: string;
  createdAt: string;
  building: string;
  component: string;
  status: 'pending' | 'received' | 'selected' | 'urgent';
  statusLabel: string;
}

export interface Contractor {
  id: string;
  name: string;
  initials: string;
  rating: number;
  reviews: number;
}

export interface Activity {
  id: string;
  type: 'comment' | 'selection' | 'alert';
  title: string;
  description: string;
  timestamp: string;
  iconBgColor: string;
  iconClass: string;
}

export interface ProjectSummary {
  activeProjects: number;
  completedProjects: number;
  pendingBids: number;
  urgentIssues: number;
}

export interface Photo {
  id: string;
  dataUrl: string; // Base64 data URL for displaying uploaded photo
}

export interface IssueMarker {
  id: string;
  position: {
    x: number;
    y: number;
    z: number;
  };
  component: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  photos: string[]; // IDs of associated photos
  installationYear?: number;
  size?: number; // Size metric for cost calculation (square feet, linear feet, etc.)
  createdAt: Date;
  updatedAt: Date;
  ashraeData?: {
    componentId: string;
    usefulLifeYears: number;
    remainingLife: number;
    replacementCost: number;
    maintenanceSchedule: { year: number; cost: number }[];
    energyEfficiencyImpact: 'low' | 'medium' | 'high';
  };
}
