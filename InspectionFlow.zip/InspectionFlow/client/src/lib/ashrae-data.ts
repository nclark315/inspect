// ASHRAE/Fannie Mae useful life & cost estimation data
// Based on ASHRAE Standard 34 and Fannie Mae Physical Needs Assessment guidance

export interface ComponentLifeData {
  id: string;
  category: string;
  component: string;
  usefulLifeYears: number;
  replacementCostRange: {
    min: number;
    max: number;
    unit: string; // e.g., "per sq ft", "each", "per linear ft"
  };
  maintenanceInterval: number; // in years
  maintenanceCost: number;
  energyEfficiencyImpact: 'low' | 'medium' | 'high';
}

// Sample data based on industry standards
export const ashraeComponentData: ComponentLifeData[] = [
  // HVAC Systems
  {
    id: 'hvac-boiler-gas',
    category: 'HVAC',
    component: 'Gas Boiler',
    usefulLifeYears: 25,
    replacementCostRange: {
      min: 25,
      max: 50,
      unit: 'per MBH'
    },
    maintenanceInterval: 1,
    maintenanceCost: 0.75,
    energyEfficiencyImpact: 'high'
  },
  {
    id: 'hvac-chiller',
    category: 'HVAC',
    component: 'Chiller',
    usefulLifeYears: 20,
    replacementCostRange: {
      min: 1000,
      max: 2000,
      unit: 'per ton'
    },
    maintenanceInterval: 1,
    maintenanceCost: 100,
    energyEfficiencyImpact: 'high'
  },
  {
    id: 'hvac-cooling-tower',
    category: 'HVAC',
    component: 'Cooling Tower',
    usefulLifeYears: 20,
    replacementCostRange: {
      min: 350,
      max: 750,
      unit: 'per ton'
    },
    maintenanceInterval: 1,
    maintenanceCost: 50,
    energyEfficiencyImpact: 'medium'
  },
  {
    id: 'hvac-air-handler',
    category: 'HVAC',
    component: 'Air Handler',
    usefulLifeYears: 25,
    replacementCostRange: {
      min: 7,
      max: 12,
      unit: 'per CFM'
    },
    maintenanceInterval: 1,
    maintenanceCost: 0.10,
    energyEfficiencyImpact: 'medium'
  },

  // Plumbing Systems
  {
    id: 'plumbing-pipe-copper',
    category: 'Plumbing',
    component: 'Copper Piping',
    usefulLifeYears: 50,
    replacementCostRange: {
      min: 25,
      max: 40,
      unit: 'per linear ft'
    },
    maintenanceInterval: 5,
    maintenanceCost: 2,
    energyEfficiencyImpact: 'low'
  },
  {
    id: 'plumbing-water-heater',
    category: 'Plumbing',
    component: 'Water Heater (Commercial)',
    usefulLifeYears: 10,
    replacementCostRange: {
      min: 3500,
      max: 8000,
      unit: 'each'
    },
    maintenanceInterval: 1,
    maintenanceCost: 200,
    energyEfficiencyImpact: 'medium'
  },

  // Electrical Systems
  {
    id: 'electrical-transformer',
    category: 'Electrical',
    component: 'Transformer',
    usefulLifeYears: 30,
    replacementCostRange: {
      min: 15,
      max: 25,
      unit: 'per KVA'
    },
    maintenanceInterval: 3,
    maintenanceCost: 1.5,
    energyEfficiencyImpact: 'medium'
  },
  {
    id: 'electrical-panel',
    category: 'Electrical',
    component: 'Electrical Panel',
    usefulLifeYears: 30,
    replacementCostRange: {
      min: 3000,
      max: 6000,
      unit: 'each'
    },
    maintenanceInterval: 5,
    maintenanceCost: 250,
    energyEfficiencyImpact: 'low'
  },

  // Building Envelope
  {
    id: 'envelope-roof-membrane',
    category: 'Building Envelope',
    component: 'Roof Membrane (EPDM)',
    usefulLifeYears: 20,
    replacementCostRange: {
      min: 8,
      max: 15,
      unit: 'per sq ft'
    },
    maintenanceInterval: 2,
    maintenanceCost: 0.15,
    energyEfficiencyImpact: 'medium'
  },
  {
    id: 'envelope-window-commercial',
    category: 'Building Envelope',
    component: 'Commercial Windows',
    usefulLifeYears: 30,
    replacementCostRange: {
      min: 40,
      max: 75,
      unit: 'per sq ft'
    },
    maintenanceInterval: 5,
    maintenanceCost: 2,
    energyEfficiencyImpact: 'high'
  },
  {
    id: 'envelope-exterior-wall',
    category: 'Building Envelope',
    component: 'Exterior Wall Finish',
    usefulLifeYears: 25,
    replacementCostRange: {
      min: 15,
      max: 30,
      unit: 'per sq ft'
    },
    maintenanceInterval: 7,
    maintenanceCost: 1.5,
    energyEfficiencyImpact: 'medium'
  },

  // Structural Elements
  {
    id: 'structural-foundation',
    category: 'Structural',
    component: 'Foundation',
    usefulLifeYears: 75,
    replacementCostRange: {
      min: 150,
      max: 300,
      unit: 'per sq ft'
    },
    maintenanceInterval: 10,
    maintenanceCost: 5,
    energyEfficiencyImpact: 'low'
  },
  {
    id: 'structural-beam',
    category: 'Structural',
    component: 'Structural Beam',
    usefulLifeYears: 75,
    replacementCostRange: {
      min: 100,
      max: 250,
      unit: 'per linear ft'
    },
    maintenanceInterval: 15,
    maintenanceCost: 10,
    energyEfficiencyImpact: 'low'
  },

  // Interior Elements
  {
    id: 'interior-flooring-tile',
    category: 'Interior',
    component: 'Tile Flooring',
    usefulLifeYears: 15,
    replacementCostRange: {
      min: 10,
      max: 20,
      unit: 'per sq ft'
    },
    maintenanceInterval: 3,
    maintenanceCost: 0.5,
    energyEfficiencyImpact: 'low'
  },
  {
    id: 'interior-ceiling',
    category: 'Interior',
    component: 'Drop Ceiling',
    usefulLifeYears: 15,
    replacementCostRange: {
      min: 3,
      max: 6,
      unit: 'per sq ft'
    },
    maintenanceInterval: 5,
    maintenanceCost: 0.25,
    energyEfficiencyImpact: 'low'
  }
];

// Function to find component data based on name or keyword
export function findComponentData(componentName: string): ComponentLifeData | undefined {
  const searchTerms = componentName.toLowerCase().split(' ');
  
  // First try exact match
  const exactMatch = ashraeComponentData.find(
    item => item.component.toLowerCase() === componentName.toLowerCase()
  );
  
  if (exactMatch) return exactMatch;
  
  // Then try partial match - find components that contain any of the search terms
  for (const data of ashraeComponentData) {
    const matchScore = searchTerms.filter(term => 
      data.component.toLowerCase().includes(term) || 
      data.category.toLowerCase().includes(term)
    ).length;
    
    if (matchScore > 0) {
      return data;
    }
  }
  
  return undefined;
}

// Calculate remaining useful life
export function calculateRemainingLife(
  componentData: ComponentLifeData, 
  installationYear: number
): number {
  const currentYear = new Date().getFullYear();
  const age = currentYear - installationYear;
  return Math.max(0, componentData.usefulLifeYears - age);
}

// Estimate replacement cost (returns average of range)
export function estimateReplacementCost(
  componentData: ComponentLifeData,
  size: number = 1 // Default multiplier if specific size is unknown
): number {
  const { min, max } = componentData.replacementCostRange;
  return ((min + max) / 2) * size;
}

// Generate maintenance schedule
export function generateMaintenanceSchedule(
  componentData: ComponentLifeData,
  installationYear: number
): { year: number; cost: number }[] {
  const currentYear = new Date().getFullYear();
  const schedule = [];
  
  // Only project forward 10 years
  const projectionEndYear = currentYear + 10;
  
  for (
    let year = installationYear + componentData.maintenanceInterval; 
    year <= projectionEndYear; 
    year += componentData.maintenanceInterval
  ) {
    if (year >= currentYear) {
      schedule.push({
        year,
        cost: componentData.maintenanceCost
      });
    }
  }
  
  return schedule;
}