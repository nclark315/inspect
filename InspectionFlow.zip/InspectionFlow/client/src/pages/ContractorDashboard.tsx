import React, { useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { pageTransition, containerTransition, itemTransition } from "@/lib/animation";
import { ProjectLead, Contractor, Activity, ProjectSummary } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { useInspectionStore } from "@/store/inspectionStore";
import { Input } from "@/components/ui/input";

const projectLeads: ProjectLead[] = [
  {
    id: "1",
    name: "Roof Repair",
    createdAt: "Created 2 days ago",
    building: "Tower One",
    component: "Roof",
    status: "pending",
    statusLabel: "Pending Bids"
  },
  {
    id: "2",
    name: "HVAC Maintenance",
    createdAt: "Created 1 week ago",
    building: "Medical Center",
    component: "HVAC",
    status: "received",
    statusLabel: "Bids Received (3)"
  },
  {
    id: "3",
    name: "Window Replacement",
    createdAt: "Created 3 days ago",
    building: "Riverside Apartments",
    component: "Windows",
    status: "selected",
    statusLabel: "Contractor Selected"
  },
  {
    id: "4",
    name: "Foundation Inspection",
    createdAt: "Created 5 days ago",
    building: "Central Mall",
    component: "Foundation",
    status: "urgent",
    statusLabel: "Urgent"
  }
];

const topContractors: Contractor[] = [
  {
    id: "1",
    name: "ABC Contractors",
    initials: "AC",
    rating: 4.5,
    reviews: 28
  },
  {
    id: "2",
    name: "Pro Services LLC",
    initials: "PS",
    rating: 4.0,
    reviews: 22
  },
  {
    id: "3",
    name: "Glass Experts Inc.",
    initials: "GE",
    rating: 5.0,
    reviews: 17
  }
];

const activities: Activity[] = [
  {
    id: "1",
    type: "comment",
    title: "New bid received for Roof Repair project",
    description: "ABC Roofing submitted a bid of $8,500",
    timestamp: "Today, 10:23 AM",
    iconBgColor: "bg-blue-100",
    iconClass: "fas fa-comment-alt text-primary"
  },
  {
    id: "2",
    type: "selection",
    title: "Contractor selected for Window Replacement",
    description: "Glass Experts Inc. was selected for the project",
    timestamp: "Yesterday, 3:45 PM",
    iconBgColor: "bg-green-100",
    iconClass: "fas fa-check text-green-600"
  },
  {
    id: "3",
    type: "alert",
    title: "Urgent issue detected in Foundation Inspection",
    description: "Structural engineer recommended immediate attention",
    timestamp: "Yesterday, 11:30 AM",
    iconBgColor: "bg-amber-100",
    iconClass: "fas fa-exclamation text-amber-600"
  }
];

const projectSummary: ProjectSummary = {
  activeProjects: 14,
  completedProjects: 28,
  pendingBids: 7,
  urgentIssues: 3
};

const ContractorDashboard: React.FC = () => {
  const [_, navigate] = useLocation();
  const { setCurrentStep } = useInspectionStore();
  
  useEffect(() => {
    setCurrentStep(6);
  }, [setCurrentStep]);

  const handleStartNewInspection = () => {
    navigate("/building-selection");
  };

  const handleViewLeadDetails = (leadId: string) => {
    // In a real app, this would navigate to a lead details page
    console.log(`Viewing details for lead ${leadId}`);
  };

  const renderStatusBadge = (status: string, label: string) => {
    let badgeClass = "";
    
    switch (status) {
      case "pending":
        badgeClass = "bg-yellow-100 text-yellow-800";
        break;
      case "received":
        badgeClass = "bg-green-100 text-green-800";
        break;
      case "selected":
        badgeClass = "bg-blue-100 text-blue-800";
        break;
      case "urgent":
        badgeClass = "bg-red-100 text-red-800";
        break;
      default:
        badgeClass = "bg-gray-100 text-gray-800";
    }
    
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${badgeClass}`}>
        <span className={`w-2 h-2 ${
          status === "pending" ? "bg-yellow-500" :
          status === "received" ? "bg-green-500" :
          status === "selected" ? "bg-blue-500" :
          "bg-red-500"
        } rounded-full mr-1`}></span>
        {label}
      </span>
    );
  };

  return (
    <motion.div
      className="animate-fade-in"
      initial="initial"
      animate="animate"
      exit="exit"
      variants={pageTransition}
    >
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">Contractor Dashboard</h1>
        <p className="text-gray-600 mb-8">Manage and track contractor leads for your building projects</p>
        
        <div className="flex flex-col lg:flex-row gap-8">
          <motion.div 
            className="lg:w-2/3"
            variants={containerTransition}
          >
            <motion.div 
              className="bg-white rounded-lg shadow-md p-6 mb-8"
              variants={itemTransition}
            >
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold">Project Leads</h2>
                <div className="flex gap-2">
                  <div className="relative">
                    <Input 
                      type="text" 
                      placeholder="Search leads..." 
                      className="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary" 
                    />
                    <i className="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                  </div>
                  <Button 
                    variant="outline"
                    className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-800 px-4 py-2 rounded-md"
                  >
                    <i className="fas fa-filter"></i>
                  </Button>
                </div>
              </div>
              
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Project</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Building</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Component</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Status</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {projectLeads.map(lead => (
                      <tr 
                        key={lead.id} 
                        className="border-b border-gray-200 hover:bg-gray-50 cursor-pointer" 
                        onClick={() => handleViewLeadDetails(lead.id)}
                      >
                        <td className="py-3 px-4">
                          <div className="font-medium text-gray-800">{lead.name}</div>
                          <div className="text-xs text-gray-500">{lead.createdAt}</div>
                        </td>
                        <td className="py-3 px-4">{lead.building}</td>
                        <td className="py-3 px-4">{lead.component}</td>
                        <td className="py-3 px-4">
                          {renderStatusBadge(lead.status, lead.statusLabel)}
                        </td>
                        <td className="py-3 px-4">
                          <button className="text-primary hover:text-blue-700 transition">
                            <i className="fas fa-eye"></i>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="mt-6 flex justify-between items-center">
                <p className="text-sm text-gray-600">Showing 4 of 14 leads</p>
                <div className="flex gap-2">
                  <Button 
                    variant="outline"
                    className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-800 px-3 py-1 rounded-md"
                  >
                    <i className="fas fa-chevron-left"></i>
                  </Button>
                  <Button 
                    className="bg-primary text-white px-3 py-1 rounded-md"
                  >
                    1
                  </Button>
                  <Button 
                    variant="outline"
                    className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-800 px-3 py-1 rounded-md"
                  >
                    2
                  </Button>
                  <Button 
                    variant="outline"
                    className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-800 px-3 py-1 rounded-md"
                  >
                    3
                  </Button>
                  <Button 
                    variant="outline"
                    className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-800 px-3 py-1 rounded-md"
                  >
                    <i className="fas fa-chevron-right"></i>
                  </Button>
                </div>
              </div>
            </motion.div>
            
            <motion.div 
              className="bg-white rounded-lg shadow-md p-6 mb-8"
              variants={itemTransition}
            >
              <h2 className="text-xl font-semibold mb-6">Recent Activity</h2>
              
              <div className="space-y-4">
                {activities.map(activity => (
                  <div key={activity.id} className="flex items-start">
                    <div className={`${activity.iconBgColor} w-10 h-10 rounded-full flex items-center justify-center mr-4 flex-shrink-0`}>
                      <i className={activity.iconClass}></i>
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">{activity.title}</p>
                      <p className="text-sm text-gray-600">{activity.description}</p>
                      <p className="text-xs text-gray-500 mt-1">{activity.timestamp}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </motion.div>
          
          <motion.div 
            className="lg:w-1/3"
            variants={containerTransition}
          >
            <motion.div 
              className="bg-white rounded-lg shadow-md p-6 mb-8"
              variants={itemTransition}
            >
              <h2 className="text-xl font-semibold mb-6">Project Summary</h2>
              
              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                  <p className="text-gray-600">Active Projects</p>
                  <p className="font-medium text-gray-800">{projectSummary.activeProjects}</p>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-primary h-2 rounded-full" style={{ width: '70%' }}></div>
                </div>
              </div>
              
              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                  <p className="text-gray-600">Completed Projects</p>
                  <p className="font-medium text-gray-800">{projectSummary.completedProjects}</p>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: '100%' }}></div>
                </div>
              </div>
              
              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                  <p className="text-gray-600">Pending Bids</p>
                  <p className="font-medium text-gray-800">{projectSummary.pendingBids}</p>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-yellow-500 h-2 rounded-full" style={{ width: '35%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <p className="text-gray-600">Urgent Issues</p>
                  <p className="font-medium text-gray-800">{projectSummary.urgentIssues}</p>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-red-500 h-2 rounded-full" style={{ width: '15%' }}></div>
                </div>
              </div>
            </motion.div>
            
            <motion.div 
              className="bg-white rounded-lg shadow-md p-6 mb-8"
              variants={itemTransition}
            >
              <h2 className="text-xl font-semibold mb-6">Top Contractors</h2>
              
              <div className="space-y-4">
                {topContractors.map(contractor => (
                  <div key={contractor.id} className="flex items-center">
                    <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center mr-4">
                      <span className="text-gray-700 font-medium">{contractor.initials}</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-800">{contractor.name}</p>
                      <div className="flex items-center">
                        <div className="flex text-amber-400">
                          {[...Array(Math.floor(contractor.rating))].map((_, i) => (
                            <i key={i} className="fas fa-star text-xs"></i>
                          ))}
                          {contractor.rating % 1 !== 0 && (
                            <i className="fas fa-star-half-alt text-xs"></i>
                          )}
                          {[...Array(5 - Math.ceil(contractor.rating))].map((_, i) => (
                            <i key={i} className="far fa-star text-xs"></i>
                          ))}
                        </div>
                        <span className="text-xs text-gray-500 ml-1">
                          {contractor.rating} ({contractor.reviews} reviews)
                        </span>
                      </div>
                    </div>
                    <button className="text-primary hover:text-blue-700 transition">
                      <i className="fas fa-chevron-right"></i>
                    </button>
                  </div>
                ))}
              </div>
              
              <Button 
                variant="outline"
                className="w-full bg-white border border-gray-300 hover:bg-gray-50 text-gray-800 font-medium rounded-md py-2 mt-6"
              >
                View All Contractors
              </Button>
            </motion.div>
            
            <motion.div 
              className="bg-primary bg-opacity-10 rounded-lg p-6"
              variants={itemTransition}
            >
              <div className="flex items-start">
                <div className="p-3 bg-primary bg-opacity-20 rounded-full mr-4">
                  <i className="fas fa-plus text-primary"></i>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800 mb-2">Start a New Inspection</h3>
                  <p className="text-sm text-gray-600 mb-4">Begin a new inspection project for any of your buildings</p>
                  <Button 
                    className="bg-primary hover:bg-blue-600 text-white px-4 py-2 rounded-md transition"
                    onClick={handleStartNewInspection}
                  >
                    New Inspection
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};

export default ContractorDashboard;
