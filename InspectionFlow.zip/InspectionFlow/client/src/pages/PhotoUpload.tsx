import { useState, useCallback, useRef, useEffect } from 'react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { 
  ChevronLeft,
  Upload, 
  X, 
  Camera, 
  Film,
  Loader2,
  Send,
  Video,
  Info,
  Box,
  Square
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useInspectionStore } from '@/store/inspectionStore';
import MobileLayout from '@/components/MobileLayout';
import { useDropzone } from 'react-dropzone';
import { Photo } from '@/lib/types';
import { v4 as uuidv4 } from 'uuid';
import { fadeIn } from '@/lib/animation';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const PhotoUpload = () => {
  const [, navigate] = useLocation();
  const { 
    selectedComponent, 
    uploadedPhotos, 
    addUploadedPhoto, 
    removeUploadedPhoto,
    notes,
    setNotes
  } = useInspectionStore();
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState<"photos" | "3d-capture">("photos");
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [isProcessing3D, setIsProcessing3D] = useState(false);
  const [is3DReady, setIs3DReady] = useState(false);
  
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Redirect if component not selected
  if (!selectedComponent) {
    navigate('/components');
    return null;
  }
  
  // Handle file drop via react-dropzone
  const onDrop = useCallback((acceptedFiles: File[]) => {
    acceptedFiles.forEach(file => {
      const reader = new FileReader();
      
      reader.onload = () => {
        // Convert file to base64 string for preview
        const dataUrl = reader.result as string;
        
        const photo: Photo = {
          id: uuidv4(),
          dataUrl
        };
        
        addUploadedPhoto(photo);
      };
      
      reader.readAsDataURL(file);
    });
  }, [addUploadedPhoto]);
  
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.heic']
    },
    maxSize: 10485760, // 10MB
  });
  
  // Start camera for 3D capture
  const startCamera = useCallback(async () => {
    try {
      if (videoRef.current) {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: "environment" }, 
          audio: false 
        });
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
    }
  }, []);
  
  // Start/stop video recording
  const toggleRecording = useCallback(() => {
    if (isRecording) {
      // Stop recording
      if (mediaRecorderRef.current) {
        mediaRecorderRef.current.stop();
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      setIsRecording(false);
    } else {
      // Start recording
      if (videoRef.current && videoRef.current.srcObject) {
        recordedChunksRef.current = [];
        const mediaRecorder = new MediaRecorder(videoRef.current.srcObject as MediaStream);
        
        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            recordedChunksRef.current.push(event.data);
          }
        };
        
        mediaRecorder.onstop = () => {
          // Process the video for 3D reconstruction
          processVideoFor3D();
        };
        
        mediaRecorderRef.current = mediaRecorder;
        mediaRecorder.start(100); // Collect 100ms chunks
        
        // Start timer
        setRecordingTime(0);
        timerRef.current = setInterval(() => {
          setRecordingTime(prevTime => prevTime + 1);
        }, 1000);
        
        setIsRecording(true);
      }
    }
  }, [isRecording]);
  
  // Process video for 3D model generation
  const processVideoFor3D = useCallback(() => {
    if (recordedChunksRef.current.length === 0) return;
    
    setIsProcessing3D(true);
    
    // Simulate 3D processing with a delay
    setTimeout(() => {
      setIsProcessing3D(false);
      setIs3DReady(true);
    }, 3000);
    
    // In a real application, we would:
    // 1. Upload the video to a server
    // 2. Process the video using photogrammetry software
    // 3. Generate a 3D model
    // 4. Return the model URL to display
  }, []);
  
  // Format seconds to MM:SS
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  // Handle tab changes
  useEffect(() => {
    if (activeTab === "3d-capture") {
      startCamera();
    } else {
      // Stop camera when switching away
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
        videoRef.current.srcObject = null;
      }
      
      // Stop recording if active
      if (isRecording) {
        toggleRecording();
      }
    }
  }, [activeTab, startCamera, isRecording, toggleRecording]);
  
  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    // Simulating API submission
    setTimeout(() => {
      setIsSubmitting(false);
      navigate('/digital-twin');
    }, 1500);
  };

  return (
    <MobileLayout>
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="flex justify-between items-center mb-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/components')}
              className="flex items-center text-gray-600 hover:text-gray-900"
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back
            </Button>
            <h1 className="text-xl font-bold text-center text-gray-900">
              {activeTab === "photos" ? "Add Photos" : "3D Capture"}
            </h1>
            <div className="w-16"></div> {/* Spacer for centering */}
          </div>
          <p className="text-gray-600 text-center">
            {activeTab === "photos" 
              ? "Upload photos of the component" 
              : "Capture video to generate 3D model"}
          </p>
        </motion.div>
        
        {/* Tabs */}
        <Tabs
          defaultValue="photos"
          value={activeTab}
          onValueChange={(value) => setActiveTab(value as "photos" | "3d-capture")}
          className="w-full"
        >
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger value="photos" className="flex items-center gap-2">
              <Camera className="h-4 w-4" />
              Photos
            </TabsTrigger>
            <TabsTrigger value="3d-capture" className="flex items-center gap-2">
              <Box className="h-4 w-4" />
              3D Capture
            </TabsTrigger>
          </TabsList>
          
          {/* Photos Tab Content */}
          <TabsContent value="photos" className="space-y-6">
            {/* Drop zone */}
            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
                isDragActive ? 'border-blue-500 bg-blue-50/50' : 'border-gray-300 hover:border-blue-400'
              }`}
            >
              <input {...getInputProps()} />
              <div className="flex flex-col items-center">
                <div className="p-3 rounded-full bg-blue-500/10 text-blue-500 mb-3">
                  {isDragActive ? <Upload className="h-6 w-6" /> : <Camera className="h-6 w-6" />}
                </div>
                {isDragActive ? (
                  <p className="text-sm text-blue-600 font-medium">Drop the files here</p>
                ) : (
                  <>
                    <p className="text-sm font-medium text-gray-700">Drag and drop photos here</p>
                    <p className="mt-1 text-xs text-gray-500">Or click to browse files</p>
                  </>
                )}
              </div>
            </div>
            
            {/* Preview area */}
            {uploadedPhotos.length > 0 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="grid grid-cols-2 gap-3"
              >
                {uploadedPhotos.map((photo, index) => (
                  <motion.div
                    key={photo.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.2, delay: index * 0.05 }}
                    className="relative rounded-md overflow-hidden bg-gray-100 aspect-square"
                  >
                    <img 
                      src={photo.dataUrl} 
                      alt={`Upload ${index + 1}`} 
                      className="w-full h-full object-cover"
                    />
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        removeUploadedPhoto(photo.id);
                      }}
                      className="absolute top-1 right-1 p-1 rounded-full bg-black/50 text-white hover:bg-black/70"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </motion.div>
                ))}
              </motion.div>
            )}
          </TabsContent>
          
          {/* 3D Capture Tab Content */}
          <TabsContent value="3d-capture" className="space-y-6">
            {/* Video preview */}
            <div className="relative bg-black rounded-lg overflow-hidden aspect-[4/3]">
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                muted 
                className="w-full h-full object-cover"
              />
              
              {/* Recording indicator */}
              {isRecording && (
                <div className="absolute top-2 right-2 bg-red-500 text-white rounded-full px-2 py-1 text-xs font-medium flex items-center">
                  <div className="w-2 h-2 rounded-full bg-white animate-pulse mr-1"></div>
                  <span>{formatTime(recordingTime)}</span>
                </div>
              )}
              
              {/* Processing overlay */}
              {isProcessing3D && (
                <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center">
                  <Loader2 className="animate-spin h-8 w-8 mb-2 text-white" />
                  <p className="text-white text-sm">Processing 3D model...</p>
                </div>
              )}
              
              {/* Ready indicator */}
              {is3DReady && (
                <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center">
                  <Box className="h-8 w-8 mb-2 text-green-400" />
                  <p className="text-white text-sm">3D model ready!</p>
                  <Button 
                    variant="outline" 
                    className="mt-4 bg-white text-black"
                    onClick={handleSubmit}
                  >
                    View 3D Model
                  </Button>
                </div>
              )}
            </div>
            
            {/* Camera controls */}
            {!is3DReady && !isProcessing3D && (
              <div className="flex justify-center">
                <Button
                  size="lg"
                  variant={isRecording ? "destructive" : "default"}
                  className="rounded-full w-16 h-16 p-0"
                  onClick={toggleRecording}
                >
                  {isRecording ? (
                    <Square className="h-6 w-6" />
                  ) : (
                    <Video className="h-6 w-6" />
                  )}
                </Button>
              </div>
            )}
            
            {/* Instructions */}
            {!isRecording && !isProcessing3D && !is3DReady && (
              <div className="bg-blue-50 p-4 rounded-lg text-sm text-blue-800">
                <div className="flex items-start mb-2">
                  <Info className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                  <p>Walk around the component and record video footage from multiple angles to create an accurate 3D model.</p>
                </div>
                <ul className="list-disc pl-8 space-y-1 text-xs text-blue-600">
                  <li>Capture at least 20 seconds of video</li>
                  <li>Move slowly around the object</li>
                  <li>Ensure good lighting conditions</li>
                  <li>Avoid reflective surfaces if possible</li>
                </ul>
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        {/* Notes textarea (only show in photos tab) */}
        {activeTab === "photos" && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Inspection Notes
            </label>
            <Textarea
              ref={textareaRef}
              placeholder="Add notes about the condition of this component..."
              className="min-h-[120px]"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </motion.div>
        )}
        
        {/* Submit button (only in photos tab, or if 3D is ready) */}
        {(activeTab === "photos" && !is3DReady) && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="pt-2"
          >
            <Button
              className="w-full"
              size="lg"
              onClick={handleSubmit}
              disabled={uploadedPhotos.length === 0 || isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-4 w-4" />
                  Submit Inspection
                </>
              )}
            </Button>
            
            <p className="text-xs text-center text-gray-500 mt-2">
              {uploadedPhotos.length === 0 ? 
                "Please add at least one photo to continue" : 
                `${uploadedPhotos.length} photo${uploadedPhotos.length !== 1 ? 's' : ''} added`
              }
            </p>
          </motion.div>
        )}
      </div>
    </MobileLayout>
  );
};

export default PhotoUpload;