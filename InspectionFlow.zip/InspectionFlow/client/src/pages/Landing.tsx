import React from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { pageTransition, containerTransition, itemTransition } from "@/lib/animation";
import { Button } from "@/components/ui/button";

const Landing: React.FC = () => {
  const [_, navigate] = useLocation();

  const handleGetStarted = () => {
    navigate("/building-selection");
  };

  return (
    <motion.div
      className="animate-fade-in"
      initial="initial"
      animate="animate"
      exit="exit"
      variants={pageTransition}
    >
      <div className="max-w-6xl mx-auto">
        <motion.div 
          className="flex flex-col md:flex-row items-center py-12"
          variants={containerTransition}
        >
          <motion.div 
            className="md:w-1/2 md:pr-8 mb-8 md:mb-0"
            variants={itemTransition}
          >
            <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
              Streamline Building Inspections & Contractor Management
            </h1>
            <p className="text-lg text-gray-600 mb-8">
              Efficiently manage building inspections, track issues, and connect with qualified contractors - all in one powerful platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                className="bg-primary hover:bg-blue-600 text-white font-medium py-6 px-6 rounded-md transition transform hover:scale-105 flex items-center justify-center"
                onClick={handleGetStarted}
              >
                Get Started
                <i className="fas fa-arrow-right ml-2"></i>
              </Button>
              <Button 
                variant="outline"
                className="bg-white hover:bg-gray-50 text-gray-700 border border-gray-300 font-medium py-6 px-6 rounded-md transition"
              >
                Learn More
              </Button>
            </div>
          </motion.div>
          <motion.div 
            className="md:w-1/2"
            variants={itemTransition}
          >
            <img 
              src="https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=600&h=400" 
              alt="Building inspection visualization" 
              className="rounded-lg shadow-xl w-full"
            />
          </motion.div>
        </motion.div>

        {/* Features Section */}
        <motion.div 
          className="py-12"
          variants={containerTransition}
          initial="initial"
          animate="animate"
        >
          <h2 className="text-2xl font-bold text-center mb-12">How BuildInspect Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <motion.div 
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition"
              variants={itemTransition}
            >
              <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <i className="fas fa-search text-primary text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-2">Inspect & Document</h3>
              <p className="text-gray-600">Document building issues with photos and detailed categorization.</p>
            </motion.div>
            <motion.div 
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition"
              variants={itemTransition}
            >
              <div className="bg-green-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <i className="fas fa-cube text-secondary text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-2">3D Building Models</h3>
              <p className="text-gray-600">Visualize issues in context with interactive digital twin models.</p>
            </motion.div>
            <motion.div 
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition"
              variants={itemTransition}
            >
              <div className="bg-amber-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <i className="fas fa-hard-hat text-accent text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-2">Contractor Matching</h3>
              <p className="text-gray-600">Automatically connect with qualified contractors for project leads.</p>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Landing;
