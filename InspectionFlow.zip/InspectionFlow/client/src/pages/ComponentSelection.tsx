import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { ChevronRight, ChevronLeft, Loader2, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useInspectionStore } from '@/store/inspectionStore';
import MobileLayout from '@/components/MobileLayout';
import { Component } from '@/lib/types';
import { LucideIcon } from 'lucide-react';
import * as LucideIcons from 'lucide-react';

const ComponentSelection = () => {
  const [, navigate] = useLocation();
  const { selectedCategory, setSelectedComponent } = useInspectionStore();
  
  // Redirect if category not selected
  if (!selectedCategory) {
    navigate('/categories');
    return null;
  }
  
  // Fetch components from the API
  const { data: components, isLoading, error } = useQuery<Component[]>({
    queryKey: ['/api/components'],
  });

  // Dynamic icon renderer
  const getDynamicIcon = (iconName: string): LucideIcon => {
    // Default to Building2 if icon not found
    return (LucideIcons as any)[iconName] || LucideIcons.Building2;
  };

  const handleComponentSelect = (component: Component) => {
    setSelectedComponent(component.id);
    navigate('/photo-upload');
  };

  return (
    <MobileLayout>
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="flex justify-between items-center mb-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/categories')}
              className="flex items-center text-gray-600 hover:text-gray-900"
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back
            </Button>
            <h1 className="text-xl font-bold text-center text-gray-900">Select Component</h1>
            <div className="w-16"></div> {/* Spacer for centering */}
          </div>
          <p className="text-gray-600 text-center">What specific part are you inspecting?</p>
        </motion.div>
        
        {/* Components List */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="space-y-4"
        >
          {isLoading ? (
            <div className="flex justify-center py-10">
              <Loader2 className="h-8 w-8 text-blue-500 animate-spin" />
            </div>
          ) : error ? (
            <div className="text-center py-8 text-red-500">
              Error loading components. Please try again.
            </div>
          ) : (
            <div className="space-y-3">
              {components && components.map((component: Component, index: number) => {
                const IconComponent = getDynamicIcon(component.icon);
                return (
                  <motion.div
                    key={component.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.1 + index * 0.05 }}
                    onClick={() => handleComponentSelect(component)}
                    className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-shadow cursor-pointer"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 rounded-lg bg-blue-500/10 text-blue-600">
                          <IconComponent className="h-5 w-5" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{component.name}</h3>
                          <p className="text-xs text-gray-600">{component.description}</p>
                          <div className="flex items-center mt-1 text-xs text-gray-500">
                            <Calendar className="h-3 w-3 mr-1" />
                            <span>Last inspection: {component.lastInspection}</span>
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 text-gray-400" />
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </motion.div>
      </div>
    </MobileLayout>
  );
};

export default ComponentSelection;