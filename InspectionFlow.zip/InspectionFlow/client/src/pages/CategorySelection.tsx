import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { ChevronRight, ChevronLeft, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useInspectionStore } from '@/store/inspectionStore';
import MobileLayout from '@/components/MobileLayout';
import { Category } from '@/lib/types';
import { LucideIcon } from 'lucide-react';
import * as LucideIcons from 'lucide-react';

const CategorySelection = () => {
  const [, navigate] = useLocation();
  const { selectedBuilding, setSelectedCategory } = useInspectionStore();
  
  // Redirect if building not selected
  if (!selectedBuilding) {
    navigate('/buildings');
    return null;
  }
  
  // Fetch categories from the API
  const { data: categories, isLoading, error } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Dynamic icon renderer
  const getDynamicIcon = (iconName: string): LucideIcon => {
    // Default to Building2 if icon not found
    return (LucideIcons as any)[iconName] || LucideIcons.Building2;
  };

  const handleCategorySelect = (category: Category) => {
    setSelectedCategory(category.id);
    navigate('/components');
  };

  return (
    <MobileLayout>
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="flex justify-between items-center mb-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/buildings')}
              className="flex items-center text-gray-600 hover:text-gray-900"
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back
            </Button>
            <h1 className="text-xl font-bold text-center text-gray-900">Select Category</h1>
            <div className="w-16"></div> {/* Spacer for centering */}
          </div>
          <p className="text-gray-600 text-center">What area are you inspecting?</p>
        </motion.div>
        
        {/* Categories Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="space-y-4"
        >
          {isLoading ? (
            <div className="flex justify-center py-10">
              <Loader2 className="h-8 w-8 text-blue-500 animate-spin" />
            </div>
          ) : error ? (
            <div className="text-center py-8 text-red-500">
              Error loading categories. Please try again.
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              {categories && categories.map((category: Category, index: number) => {
                const IconComponent = getDynamicIcon(category.icon);
                return (
                  <motion.div
                    key={category.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.1 + index * 0.05 }}
                    onClick={() => handleCategorySelect(category)}
                    className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
                  >
                    <div className={`p-5 flex flex-col items-center justify-center ${category.bgColor}`}>
                      <div className={`p-3 rounded-full ${category.bgColor} ${category.iconColor}`}>
                        <IconComponent className="h-6 w-6" />
                      </div>
                      <h3 className="mt-3 font-semibold text-gray-900 text-center">{category.name}</h3>
                      <p className="text-xs text-gray-600 text-center mt-1">{category.description}</p>
                      <ChevronRight className="h-4 w-4 text-gray-400 mt-2" />
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </motion.div>
      </div>
    </MobileLayout>
  );
};

export default CategorySelection;