import { useEffect, useRef, useState, useCallback } from 'react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { 
  ChevronLeft, 
  Camera, 
  Tag, 
  Layers, 
  Download, 
  Info, 
  Plus,
  AlertTriangle,
  DollarSign,
  Clock 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import MobileLayout from '@/components/MobileLayout';
import { useInspectionStore } from '@/store/inspectionStore';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { IssueMarker } from '@/lib/types';
import IssueForm from '@/components/IssueForm';
import { Dialog, DialogContent } from '@/components/ui/dialog';

// Simple 3D building model
const createSimpleBuildingModel = () => {
  // Building base
  const buildingGeometry = new THREE.BoxGeometry(5, 10, 5);
  const buildingMaterial = new THREE.MeshPhongMaterial({ 
    color: 0xeeeeff,
    flatShading: true,
  });
  const building = new THREE.Mesh(buildingGeometry, buildingMaterial);
  building.position.y = 5; // Move up half height
  
  // Roof
  const roofGeometry = new THREE.ConeGeometry(5, 2, 4);
  const roofMaterial = new THREE.MeshPhongMaterial({ color: 0x885533 });
  const roof = new THREE.Mesh(roofGeometry, roofMaterial);
  roof.position.y = 11; // Top of building + half height of roof
  roof.rotation.y = Math.PI / 4; // Orient the square pyramid
  
  // Windows
  const windowGroup = new THREE.Group();
  const windowGeometry = new THREE.BoxGeometry(1, 1.5, 0.1);
  const windowMaterial = new THREE.MeshPhongMaterial({ 
    color: 0x88ccff,
    transparent: true,
    opacity: 0.7,
  });
  
  // Front windows (2x3 grid)
  for (let x = -1.5; x <= 1.5; x += 3) {
    for (let y = 2; y <= 8; y += 3) {
      const windowMesh = new THREE.Mesh(windowGeometry, windowMaterial);
      windowMesh.position.set(x, y, 2.55);
      windowGroup.add(windowMesh);
    }
  }
  
  // Side windows
  for (let x = -2.55; x <= 2.55; x += 5.1) {
    for (let y = 2; y <= 8; y += 3) {
      for (let z = -1.5; z <= 1.5; z += 3) {
        const windowMesh = new THREE.Mesh(windowGeometry, windowMaterial);
        windowMesh.position.set(x, y, z);
        windowMesh.rotation.y = Math.PI / 2; // Rotate to face outward
        windowGroup.add(windowMesh);
      }
    }
  }
  
  // Door
  const doorGeometry = new THREE.BoxGeometry(1.5, 2.5, 0.1);
  const doorMaterial = new THREE.MeshPhongMaterial({ color: 0x885533 });
  const door = new THREE.Mesh(doorGeometry, doorMaterial);
  door.position.set(0, 1.25, 2.55);
  
  // Ground
  const groundGeometry = new THREE.PlaneGeometry(30, 30);
  const groundMaterial = new THREE.MeshPhongMaterial({ 
    color: 0x88aa55,
    side: THREE.DoubleSide,
  });
  const ground = new THREE.Mesh(groundGeometry, groundMaterial);
  ground.rotation.x = Math.PI / 2;
  ground.position.y = 0;
  
  // Group all elements
  const buildingGroup = new THREE.Group();
  buildingGroup.add(building);
  buildingGroup.add(roof);
  buildingGroup.add(windowGroup);
  buildingGroup.add(door);
  buildingGroup.add(ground);
  
  return buildingGroup;
};

// Issue marker 3D object
const createIssueMarker = (position: THREE.Vector3, issueId: string) => {
  const markerGeometry = new THREE.SphereGeometry(0.3, 16, 16);
  const markerMaterial = new THREE.MeshBasicMaterial({ 
    color: 0xff3333,
    transparent: true,
    opacity: 0.8,
  });
  
  const marker = new THREE.Mesh(markerGeometry, markerMaterial);
  marker.position.copy(position);
  marker.userData = { issueId };
  
  // Pulsing animation
  const pulse = () => {
    const scale = 1 + 0.2 * Math.sin(Date.now() * 0.005);
    marker.scale.set(scale, scale, scale);
    requestAnimationFrame(pulse);
  };
  pulse();
  
  return marker;
};

const DigitalTwinViewer = () => {
  const [, navigate] = useLocation();
  const { selectedComponent, selectedBuilding } = useInspectionStore();
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'explore' | 'issues'>('explore');
  const [issueMarkers, setIssueMarkers] = useState<IssueMarker[]>([]);
  const [selectedIssue, setSelectedIssue] = useState<IssueMarker | null>(null);
  const [showIssueForm, setShowIssueForm] = useState(false);
  const [newIssuePosition, setNewIssuePosition] = useState<THREE.Vector3 | null>(null);
  
  // ThreeJS refs
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const buildingModelRef = useRef<THREE.Group | null>(null);
  const markerRefs = useRef<Map<string, THREE.Mesh>>(new Map());
  
  // Redirect if component not selected
  if (!selectedComponent && !selectedBuilding) {
    navigate('/buildings');
    return null;
  }
  
  useEffect(() => {
    if (!canvasRef.current) return;
    
    // Setup scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xaaccff);
    sceneRef.current = scene;
    
    // Camera
    const camera = new THREE.PerspectiveCamera(
      75, 
      window.innerWidth / window.innerHeight, 
      0.1, 
      1000
    );
    camera.position.set(15, 10, 15);
    camera.lookAt(0, 5, 0);
    cameraRef.current = camera;
    
    // Renderer
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current,
      antialias: true,
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    rendererRef.current = renderer;
    
    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.1;
    controls.maxDistance = 30;
    controls.minDistance = 8;
    controls.maxPolarAngle = Math.PI / 2 - 0.1; // Prevent going below ground
    controlsRef.current = controls;
    
    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(10, 20, 10);
    directionalLight.castShadow = true;
    scene.add(directionalLight);
    
    // Add building model
    const buildingModel = createSimpleBuildingModel();
    scene.add(buildingModel);
    buildingModelRef.current = buildingModel;
    
    // Add sample issue markers (in a real app, these would come from API)
    const sampleIssues: IssueMarker[] = [
      { 
        id: '1', 
        position: {
          x: -1.5, 
          y: 5, 
          z: 2.6
        },
        component: 'Window Frame',
        description: 'Window frame damage with visible cracks',
        severity: 'medium',
        photos: [],
        installationYear: 2015,
        size: 4.5, // Square feet
        createdAt: new Date(),
        updatedAt: new Date(),
        ashraeData: {
          componentId: 'envelope-window-commercial',
          usefulLifeYears: 30,
          remainingLife: 20,
          replacementCost: 258.75, // 4.5 sq ft * $57.5 avg cost
          maintenanceSchedule: [
            { year: 2025, cost: 9 }
          ],
          energyEfficiencyImpact: 'high'
        }
      },
      { 
        id: '2', 
        position: {
          x: 0, 
          y: 1.25, 
          z: 2.6
        },
        component: 'Door Hinge',
        description: 'Door hinge issue causing sticking',
        severity: 'low',
        photos: [],
        installationYear: 2018,
        size: 1,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];
    
    sampleIssues.forEach(issue => {
      const position = new THREE.Vector3(
        issue.position.x,
        issue.position.y,
        issue.position.z
      );
      const marker = createIssueMarker(position, issue.id);
      scene.add(marker);
      markerRefs.current.set(issue.id, marker);
    });
    
    setIssueMarkers(sampleIssues);
    setIsLoading(false);
    
    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      if (controlsRef.current) controlsRef.current.update();
      if (rendererRef.current && cameraRef.current && sceneRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };
    animate();
    
    // Handle resize
    const handleResize = () => {
      if (cameraRef.current && rendererRef.current) {
        cameraRef.current.aspect = window.innerWidth / window.innerHeight;
        cameraRef.current.updateProjectionMatrix();
        rendererRef.current.setSize(window.innerWidth, window.innerHeight);
      }
    };
    window.addEventListener('resize', handleResize);
    
    // Add click handler to canvas for issue tagging
    const handleCanvasClick = (event: MouseEvent) => {
      if (activeTab !== 'issues') return;
      
      // Calculate normalized device coordinates
      const canvas = canvasRef.current;
      if (!canvas || !cameraRef.current || !sceneRef.current) return;
      
      const rect = canvas.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / canvas.clientWidth) * 2 - 1;
      const y = -((event.clientY - rect.top) / canvas.clientHeight) * 2 + 1;
      
      // Create a THREE.Vector2 for the raycaster
      const mouse = new THREE.Vector2(x, y);
      
      // Raycast to find intersection with building
      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(mouse, cameraRef.current);
      
      // First check if we're clicking on an existing marker
      const markers = Array.from(markerRefs.current.values());
      const markerIntersects = raycaster.intersectObjects(markers);
      
      if (markerIntersects.length > 0) {
        // User clicked on an existing marker
        const marker = markerIntersects[0].object;
        const issueId = marker.userData.issueId;
        const issue = issueMarkers.find(i => i.id === issueId);
        
        if (issue) {
          // Show issue details
          setSelectedIssue(issue as IssueMarker);
          setShowIssueForm(true);
          return;
        }
      }
      
      // Filter to only include building parts (exclude markers, ground)
      const buildingParts = buildingModelRef.current?.children.filter(
        child => child.type === 'Mesh' && child !== buildingModelRef.current?.children[4] // Exclude ground
      ) || [];
      
      const intersects = raycaster.intersectObjects(buildingParts, true);
      
      if (intersects.length > 0) {
        const intersection = intersects[0];
        // Open issue form at intersection point
        setNewIssuePosition(intersection.point);
        setShowIssueForm(true);
      }
    };
    
    canvasRef.current.addEventListener('click', handleCanvasClick);
    
    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (canvasRef.current) {
        canvasRef.current.removeEventListener('click', handleCanvasClick);
      }
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, [activeTab]);

  // Handle issue form submission
  const handleIssueSubmit = useCallback((issue: Partial<IssueMarker>) => {
    if (!sceneRef.current) return;
    
    // Create a unique ID if it's a new issue
    const isNewIssue = !issue.id;
    const issueId = issue.id || `issue-${Date.now()}`;
    
    // Create full issue object
    const fullIssue: IssueMarker = {
      id: issueId,
      position: issue.position || { x: 0, y: 0, z: 0 },
      component: issue.component || 'Unknown',
      description: issue.description || 'No description',
      severity: issue.severity || 'medium',
      photos: issue.photos || [],
      createdAt: issue.createdAt || new Date(),
      updatedAt: new Date(),
      ...(issue.installationYear && { installationYear: issue.installationYear }),
      ...(issue.size && { size: issue.size }),
      ...(issue.ashraeData && { ashraeData: issue.ashraeData })
    };
    
    // If it's a new issue, create a marker
    if (isNewIssue && newIssuePosition) {
      const position = new THREE.Vector3(
        newIssuePosition.x,
        newIssuePosition.y,
        newIssuePosition.z
      );
      
      // Create position for the issue object
      fullIssue.position = {
        x: position.x,
        y: position.y,
        z: position.z
      };
      
      // Create 3D marker
      const marker = createIssueMarker(position, issueId);
      sceneRef.current.add(marker);
      markerRefs.current.set(issueId, marker);
      
      // Add to issue list
      setIssueMarkers(prev => [...prev, fullIssue]);
    } else {
      // Update existing issue
      setIssueMarkers(prev => 
        prev.map(i => i.id === fullIssue.id ? { ...i, ...fullIssue } : i)
      );
    }
    
    // Close form
    setShowIssueForm(false);
    setSelectedIssue(null);
    setNewIssuePosition(null);
  }, [newIssuePosition]);
  
  // Calculate severity color
  const getSeverityColor = (severity: IssueMarker['severity']) => {
    switch (severity) {
      case 'low': return 'bg-blue-500';
      case 'medium': return 'bg-amber-500';
      case 'high': return 'bg-orange-500'; 
      case 'critical': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <MobileLayout>
      <div className="absolute inset-0 flex flex-col">
        {/* 3D Canvas (full screen) */}
        <canvas 
          ref={canvasRef} 
          className="absolute inset-0 w-full h-full z-0"
        />
        
        {/* Loading overlay */}
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-50">
            <div className="text-white text-center">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-white mx-auto"></div>
              <p className="mt-4">Loading 3D Model...</p>
            </div>
          </div>
        )}
        
        {/* Top bar */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="relative z-10 flex justify-between items-center p-4 bg-white/90 backdrop-blur-md"
        >
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/photo-upload')}
            className="flex items-center text-gray-600 hover:text-gray-900"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back
          </Button>
          
          <h1 className="text-lg font-bold text-center text-gray-900">Digital Twin</h1>
          
          <div className="w-16"></div> {/* Spacer for centering */}
        </motion.div>
        
        {/* Bottom toolbar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="relative z-10 mt-auto p-4 bg-white/90 backdrop-blur-md"
        >
          <div className="flex justify-around">
            <Button
              variant={activeTab === 'explore' ? 'default' : 'outline'}
              className="px-4"
              onClick={() => setActiveTab('explore')}
            >
              <Layers className="h-5 w-5 mr-1" />
              Explore
            </Button>
            
            <Button
              variant={activeTab === 'issues' ? 'default' : 'outline'}
              className="px-4"
              onClick={() => setActiveTab('issues')}
            >
              <Tag className="h-5 w-5 mr-1" />
              Issues
            </Button>
          </div>
          
          {/* Contextual buttons based on active tab */}
          <div className="mt-3 flex justify-around">
            {activeTab === 'explore' ? (
              <>
                <Button variant="outline" size="sm">
                  <Camera className="h-4 w-4 mr-1" />
                  Screenshot
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-1" />
                  Download Model
                </Button>
                <Button variant="outline" size="sm">
                  <Info className="h-4 w-4 mr-1" />
                  Info
                </Button>
              </>
            ) : (
              <>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    if (buildingModelRef.current) {
                      setNewIssuePosition(new THREE.Vector3(0, 5, 0));
                      setShowIssueForm(true);
                    }
                  }}
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add Issue
                </Button>
                <Button variant="outline" size="sm">
                  <Tag className="h-4 w-4 mr-1" />
                  Issues ({issueMarkers.length})
                </Button>
              </>
            )}
          </div>
          
          {/* Issue list (when in issues tab) */}
          {activeTab === 'issues' && issueMarkers.length > 0 && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="mt-3 bg-white rounded-md p-2 max-h-36 overflow-y-auto"
            >
              <h3 className="text-sm font-medium mb-2">Tagged Issues</h3>
              <div className="space-y-2">
                {issueMarkers.map(issue => (
                  <div 
                    key={issue.id} 
                    className="flex items-center justify-between p-2 bg-gray-50 rounded text-xs cursor-pointer hover:bg-gray-100"
                    onClick={() => {
                      setSelectedIssue(issue);
                      setShowIssueForm(true);
                    }}
                  >
                    <div className="flex items-center">
                      <div className={`h-2 w-2 rounded-full ${getSeverityColor(issue.severity)} mr-2`}></div>
                      <div>
                        <div className="font-medium">{issue.component}</div>
                        <div className="text-gray-500 text-xs mt-0.5">{issue.description}</div>
                      </div>
                    </div>
                    {issue.ashraeData && (
                      <div className="flex items-center gap-2">
                        {issue.ashraeData.remainingLife <= 2 ? (
                          <Badge variant="destructive" className="text-[9px] py-0">End of Life</Badge>
                        ) : issue.ashraeData.remainingLife <= 5 ? (
                          <Badge variant="secondary" className="text-[9px] py-0">Replace Soon</Badge>
                        ) : null}
                        <DollarSign className="h-3 w-3 text-green-600" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </motion.div>
        
        {/* Issue Form Dialog */}
        <Dialog open={showIssueForm} onOpenChange={setShowIssueForm}>
          <DialogContent className="max-w-md w-[95%] p-0">
            <IssueForm
              position={
                selectedIssue ? 
                  selectedIssue.position : 
                  newIssuePosition ? 
                    { x: newIssuePosition.x, y: newIssuePosition.y, z: newIssuePosition.z } : 
                    undefined
              }
              initialIssue={selectedIssue || {}}
              onSubmit={handleIssueSubmit}
              onCancel={() => {
                setShowIssueForm(false);
                setSelectedIssue(null);
                setNewIssuePosition(null);
              }}
            />
          </DialogContent>
        </Dialog>
      </div>
    </MobileLayout>
  );
};

export default DigitalTwinViewer;