import { useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import {
  Building2,
  Camera,
  Clipboard,
  ArrowRight,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Flame
} from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import MobileLayout from '@/components/MobileLayout';

const Home = () => {
  const { user } = useAuthStore();
  const [, setLocation] = useLocation();

  // Redirect based on role for more specific dashboards
  useEffect(() => {
    if (user?.role === 'contractor') {
      setLocation('/contractor');
    }
  }, [user, setLocation]);

  // Cards for the inspector role
  const inspectorCards = [
    {
      title: 'Start Inspection',
      description: 'Create a new building inspection report',
      icon: Camera,
      bgColor: 'bg-blue-500/10',
      textColor: 'text-blue-600',
      path: '/buildings',
    },
    {
      title: 'View Reports',
      description: 'Access past inspection reports',
      icon: Clipboard,
      bgColor: 'bg-purple-500/10',
      textColor: 'text-purple-600',
      path: '/reports',
    },
    {
      title: 'Building Database',
      description: 'View all registered buildings',
      icon: Building2,
      bgColor: 'bg-emerald-500/10',
      textColor: 'text-emerald-600',
      path: '/buildings',
    },
  ];

  // Recent activity (could be fetched from an API in a real app)
  const recentActivity = [
    {
      title: 'Eastern Towers Inspection',
      time: '2 hours ago',
      status: 'completed',
      icon: CheckCircle2,
      iconColor: 'text-green-500',
    },
    {
      title: 'Westfield Mall HVAC',
      time: '1 day ago',
      status: 'issue',
      icon: AlertTriangle,
      iconColor: 'text-amber-500',
    },
    {
      title: 'Central Apartments Electrical',
      time: '3 days ago',
      status: 'urgent',
      icon: Flame,
      iconColor: 'text-red-500',
    },
  ];

  return (
    <MobileLayout>
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h1 className="text-2xl font-bold text-gray-900 mb-1">
            Welcome back, {user?.name || 'Inspector'}
          </h1>
          <p className="text-gray-600">
            {new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="grid grid-cols-1 gap-4"
        >
          {inspectorCards.map((card, index) => (
            <Link key={card.title} href={card.path}>
              <motion.a
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.1 + index * 0.1 }}
                className={`block p-4 rounded-xl ${card.bgColor} hover:shadow-md transition-all`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className={`p-3 rounded-lg ${card.bgColor} ${card.textColor}`}>
                      <card.icon className="h-6 w-6" />
                    </div>
                    <div className="ml-4">
                      <h3 className="font-semibold text-gray-900">{card.title}</h3>
                      <p className="text-sm text-gray-600">{card.description}</p>
                    </div>
                  </div>
                  <ArrowRight className="h-5 w-5 text-gray-400" />
                </div>
              </motion.a>
            </Link>
          ))}
        </motion.div>

        <div className="pt-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Recent Activity</h2>
            <Button variant="ghost" size="sm" className="text-sm text-blue-600">
              View all
            </Button>
          </div>
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="space-y-3"
          >
            {recentActivity.map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: 0.3 + index * 0.1 }}
                className="flex items-center p-3 bg-white rounded-lg shadow-sm"
              >
                <div className={`p-2 rounded-full ${item.iconColor} bg-opacity-10`}>
                  <item.icon className={`h-5 w-5 ${item.iconColor}`} />
                </div>
                <div className="ml-3 flex-1">
                  <p className="text-sm font-medium text-gray-900">{item.title}</p>
                  <div className="flex items-center">
                    <Clock className="h-3 w-3 text-gray-400 mr-1" />
                    <span className="text-xs text-gray-500">{item.time}</span>
                  </div>
                </div>
                <Button variant="ghost" size="sm" className="text-xs">
                  Details
                </Button>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </MobileLayout>
  );
};

export default Home;