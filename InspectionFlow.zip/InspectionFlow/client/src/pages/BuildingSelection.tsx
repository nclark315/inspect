import { useState } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Building2, MapPin, Calendar, ChevronRight, Search, Loader2 } from 'lucide-react';
import { useInspectionStore } from '@/store/inspectionStore';
import MobileLayout from '@/components/MobileLayout';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import type { Building } from '@/lib/types';

const BuildingSelection = () => {
  const [, navigate] = useLocation();
  const { setSelectedBuilding } = useInspectionStore();
  const [searchQuery, setSearchQuery] = useState('');
  
  // Fetch buildings from the API
  const { data: buildings, isLoading, error } = useQuery<Building[]>({
    queryKey: ['/api/buildings'],
  });
  
  // Filter buildings based on search query
  const filteredBuildings = buildings ? 
    buildings.filter((building) => 
      building.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      building.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      building.type.toLowerCase().includes(searchQuery.toLowerCase())
    ) : [];
    
  const handleBuildingSelect = (building: Building) => {
    setSelectedBuilding(building.id);
    navigate('/categories');
  };

  return (
    <MobileLayout>
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h1 className="text-2xl font-bold text-gray-900">Select a Building</h1>
          <p className="text-gray-600">Choose a building to inspect</p>
        </motion.div>
        
        {/* Search */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <Input
            placeholder="Search buildings..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        {/* Building List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 text-blue-500 animate-spin" />
            </div>
          ) : error ? (
            <div className="text-center py-8 text-red-500">
              Error loading buildings. Please try again.
            </div>
          ) : filteredBuildings.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No buildings match your search criteria.
            </div>
          ) : (
            filteredBuildings.map((building: Building, index: number) => (
              <motion.div
                key={building.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.1 + index * 0.05 }}
                className="bg-white rounded-lg shadow-sm overflow-hidden"
              >
                <div className="h-36 overflow-hidden relative">
                  <img 
                    src={building.imageUrl} 
                    alt={building.name} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  <div className="absolute bottom-0 left-0 p-3 text-white">
                    <div className="flex items-center space-x-1">
                      <Building2 className="h-4 w-4" />
                      <span className="text-sm font-medium">{building.type}</span>
                    </div>
                  </div>
                </div>
                
                <div className="p-4">
                  <h3 className="font-semibold text-gray-900 mb-1">{building.name}</h3>
                  <div className="flex items-start space-x-2 mb-3">
                    <MapPin className="h-4 w-4 text-gray-500 mt-0.5" />
                    <p className="text-sm text-gray-600">{building.address}</p>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center text-xs text-gray-500">
                      <Calendar className="h-3.5 w-3.5 mr-1" />
                      <span>Last inspection: {building.lastInspection}</span>
                    </div>
                    <Button 
                      size="sm" 
                      onClick={() => handleBuildingSelect(building)}
                      className={cn("text-xs")}
                    >
                      Select <ChevronRight className="ml-1 h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>
    </MobileLayout>
  );
};

export default BuildingSelection;