import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  AlertTriangle, 
  Wrench, 
  Clock, 
  DollarSign, 
  Calendar,
  Info,
  ThermometerSun
} from 'lucide-react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardFooter 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { IssueMarker } from '@/lib/types';
import { 
  findComponentData, 
  calculateRemainingLife, 
  estimateReplacementCost, 
  generateMaintenanceSchedule, 
  ComponentLifeData 
} from '@/lib/ashrae-data';
import { Badge } from '@/components/ui/badge';

interface IssueFormProps {
  position?: { x: number; y: number; z: number };
  onSubmit: (issue: Partial<IssueMarker>) => void;
  onCancel: () => void;
  initialIssue?: Partial<IssueMarker>;
}

const IssueForm: React.FC<IssueFormProps> = ({ 
  position, 
  onSubmit, 
  onCancel,
  initialIssue = {} 
}) => {
  const [issue, setIssue] = useState<Partial<IssueMarker>>({
    component: '',
    description: '',
    severity: 'medium',
    photos: [],
    installationYear: new Date().getFullYear() - 5, // Default to 5 years ago
    size: 1,
    ...initialIssue,
    position: position || initialIssue.position || { x: 0, y: 0, z: 0 }
  });
  
  const [componentData, setComponentData] = useState<ComponentLifeData | null>(null);
  const [showAshraeData, setShowAshraeData] = useState(false);
  const [ashraeEstimates, setAshraeEstimates] = useState<IssueMarker['ashraeData']>();
  
  // Update ASHRAE data when component or installation year changes
  useEffect(() => {
    if (issue.component) {
      const data = findComponentData(issue.component);
      setComponentData(data || null);
      
      if (data && issue.installationYear) {
        const remainingLife = calculateRemainingLife(data, issue.installationYear);
        const replacementCost = estimateReplacementCost(data, issue.size);
        const maintenanceSchedule = generateMaintenanceSchedule(data, issue.installationYear);
        
        setAshraeEstimates({
          componentId: data.id,
          usefulLifeYears: data.usefulLifeYears,
          remainingLife,
          replacementCost,
          maintenanceSchedule,
          energyEfficiencyImpact: data.energyEfficiencyImpact
        });
      } else {
        setAshraeEstimates(undefined);
      }
    }
  }, [issue.component, issue.installationYear, issue.size]);
  
  const handleChange = (
    field: keyof IssueMarker,
    value: any
  ) => {
    setIssue(prev => ({ ...prev, [field]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newIssue: Partial<IssueMarker> = {
      ...issue,
      ashraeData: ashraeEstimates,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    onSubmit(newIssue);
  };
  
  // Generate current year and past years for installation selector
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 50 }, (_, i) => currentYear - 49 + i);
  
  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Issue Details</CardTitle>
        <CardDescription>
          Add information about the component issue
        </CardDescription>
      </CardHeader>
      
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="component">Component Name</Label>
            <Input
              id="component"
              value={issue.component}
              onChange={(e) => handleChange('component', e.target.value)}
              placeholder="e.g., Roof Membrane, Window, HVAC Unit"
              required
            />
            {componentData && (
              <p className="text-xs text-green-600">
                Matched ASHRAE data: {componentData.category} / {componentData.component}
              </p>
            )}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={issue.description}
              onChange={(e) => handleChange('description', e.target.value)}
              placeholder="Describe the issue..."
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="severity">Severity</Label>
            <Select
              value={issue.severity as string}
              onValueChange={(value) => handleChange('severity', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select severity" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="installationYear">Installation Year</Label>
              <Select
                value={issue.installationYear?.toString()}
                onValueChange={(value) => handleChange('installationYear', parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select year" />
                </SelectTrigger>
                <SelectContent>
                  {years.map(year => (
                    <SelectItem key={year} value={year.toString()}>
                      {year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="size">Size/Quantity</Label>
              <Input
                id="size"
                type="number"
                min="0.1"
                step="0.1"
                value={issue.size?.toString()}
                onChange={(e) => handleChange('size', parseFloat(e.target.value))}
                placeholder="Unit size"
              />
              {componentData && (
                <p className="text-xs text-gray-500">
                  {componentData.replacementCostRange.unit}
                </p>
              )}
            </div>
          </div>
          
          {/* ASHRAE Data Section */}
          {componentData && ashraeEstimates && (
            <div>
              <div 
                className="flex items-center justify-between cursor-pointer"
                onClick={() => setShowAshraeData(!showAshraeData)}
              >
                <div className="flex items-center gap-2">
                  <Info className="h-4 w-4 text-blue-500" />
                  <span className="font-medium text-sm">
                    ASHRAE Data & Cost Estimates
                  </span>
                </div>
                <Badge variant="outline">
                  {showAshraeData ? 'Hide' : 'Show'}
                </Badge>
              </div>
              
              {showAshraeData && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-3 p-3 bg-slate-50 rounded-lg space-y-3"
                >
                  <div className="flex items-start gap-2">
                    <Clock className="h-4 w-4 text-blue-700 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-sm">Useful Life</h4>
                      <p className="text-xs text-gray-600">
                        Expected: {ashraeEstimates.usefulLifeYears} years
                      </p>
                      <p className="text-xs text-gray-600">
                        Remaining: {ashraeEstimates.remainingLife} years
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-2">
                    <DollarSign className="h-4 w-4 text-green-600 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-sm">Replacement Cost</h4>
                      <p className="text-xs text-gray-600">
                        Estimated: ${ashraeEstimates.replacementCost.toLocaleString()} 
                        {componentData.replacementCostRange.unit !== 'each' 
                          ? ` (${componentData.replacementCostRange.unit})` 
                          : ''}
                      </p>
                      <p className="text-xs text-gray-600">
                        Range: ${componentData.replacementCostRange.min.toLocaleString()} - 
                        ${componentData.replacementCostRange.max.toLocaleString()}
                        {componentData.replacementCostRange.unit !== 'each' 
                          ? ` ${componentData.replacementCostRange.unit}` 
                          : ''}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-2">
                    <Wrench className="h-4 w-4 text-amber-600 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-sm">Maintenance</h4>
                      <p className="text-xs text-gray-600">
                        Interval: Every {componentData.maintenanceInterval} year(s)
                      </p>
                      <p className="text-xs text-gray-600">
                        Next maintenance: {ashraeEstimates.maintenanceSchedule.length > 0 
                          ? ashraeEstimates.maintenanceSchedule[0].year 
                          : 'None scheduled'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-2">
                    <ThermometerSun className="h-4 w-4 text-purple-600 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-sm">Energy Efficiency Impact</h4>
                      <div className="flex items-center mt-1">
                        <Badge variant={
                          ashraeEstimates.energyEfficiencyImpact === 'low' 
                            ? 'outline' 
                            : ashraeEstimates.energyEfficiencyImpact === 'medium' 
                              ? 'secondary' 
                              : 'default'
                        }>
                          {ashraeEstimates.energyEfficiencyImpact}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
          )}
        </CardContent>
        
        <CardFooter className="flex justify-between">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit">
            Save Issue
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
};

export default IssueForm;