import React from "react";
import { useLocation, Link } from "wouter";
import { motion } from "framer-motion";

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [location] = useLocation();
  const showStepIndicator = location !== "/" && location !== "/contractor-dashboard";

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 font-sans">
      {/* Navigation */}
      <nav className="bg-white shadow-sm py-4 px-6">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/">
            <div className="flex items-center cursor-pointer">
              <i className="fas fa-building text-primary text-2xl mr-2"></i>
              <span className="text-xl font-bold text-gray-800">BuildInspect</span>
            </div>
          </Link>
          <div>
            <button className="text-gray-600 hover:text-primary transition hidden md:inline-block mr-4">
              Help
            </button>
            <button className="text-gray-600 hover:text-primary transition hidden md:inline-block mr-4">
              About
            </button>
            <button className="bg-primary text-white px-4 py-2 rounded-md hover:bg-blue-600 transition">
              Sign In
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 container mx-auto px-4 py-8">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 px-6">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <div className="flex items-center">
                <i className="fas fa-building text-primary text-2xl mr-2"></i>
                <span className="text-xl font-bold">BuildInspect</span>
              </div>
              <p className="text-gray-400 mt-2">
                Simplifying building inspections and contractor management
              </p>
            </div>

            <div className="flex gap-6">
              <a href="#" className="text-gray-400 hover:text-white transition">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                Contact Us
              </a>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-6 pt-6 text-center text-gray-400 text-sm">
            &copy; 2023 BuildInspect. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
