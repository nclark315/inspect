import React from "react";
import { useLocation } from "wouter";

const steps = [
  { path: "/building-selection", label: "Building", icon: "fas fa-building" },
  { path: "/category-selection", label: "Category", icon: "fas fa-tag" },
  { path: "/component-selection", label: "Component", icon: "fas fa-wrench" },
  { path: "/photo-upload", label: "Photos", icon: "fas fa-camera" },
  { path: "/digital-twin", label: "3D View", icon: "fas fa-cube" },
];

interface StepIndicatorProps {
  className?: string;
}

const StepIndicator: React.FC<StepIndicatorProps> = ({ className = "" }) => {
  const [location] = useLocation();
  
  const currentStepIndex = steps.findIndex((step) => step.path === location);

  return (
    <div className={`mb-8 ${className}`}>
      <div className="flex justify-between items-center max-w-3xl mx-auto px-4">
        {steps.map((step, index) => {
          let statusClass = "";
          if (index < currentStepIndex) {
            statusClass = "completed";
          } else if (index === currentStepIndex) {
            statusClass = "active";
          }

          return (
            <div 
              key={step.path} 
              className={`step-item flex flex-col items-center w-1/5 ${statusClass}`}
            >
              <div className={`step-circle w-10 h-10 rounded-full ${
                statusClass === 'completed' 
                  ? 'bg-green-500 text-white' 
                  : statusClass === 'active'
                    ? 'bg-primary text-white'
                    : 'bg-gray-200 text-gray-600'
              } flex items-center justify-center mb-2`}>
                <i className={step.icon}></i>
              </div>
              <div className="text-xs text-center font-medium">{step.label}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default StepIndicator;
