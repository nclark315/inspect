import React, { useState, useRef, useEffect } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const dropdownVariants = cva(
  "relative w-full",
  {
    variants: {
      variant: {
        default: "",
        error: "",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
);

export interface DropdownProps
  extends React.SelectHTMLAttributes<HTMLSelectElement>,
    VariantProps<typeof dropdownVariants> {
  options: { value: string; label: string }[];
  label?: string;
  placeholder?: string;
  error?: string;
  icon?: string;
}

const Dropdown = React.forwardRef<HTMLSelectElement, DropdownProps>(
  (
    {
      className,
      variant,
      options,
      label,
      placeholder = "Select an option",
      error,
      icon = "fas fa-chevron-down",
      ...props
    },
    ref
  ) => {
    return (
      <div className={cn(dropdownVariants({ variant }), className)}>
        {label && (
          <label
            htmlFor={props.id}
            className="block text-sm font-medium text-gray-700 mb-2"
          >
            {label}
          </label>
        )}
        <div className="relative">
          <select
            ref={ref}
            className={cn(
              "block w-full border border-gray-300 rounded-md py-3 px-4 pr-8 appearance-none",
              "focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary",
              error && "border-red-500 focus:ring-red-500 focus:border-red-500"
            )}
            {...props}
          >
            {placeholder && (
              <option value="" disabled>
                {placeholder}
              </option>
            )}
            {options.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
          <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
            <i className={`${icon} text-gray-400`}></i>
          </div>
        </div>
        {error && (
          <p className="mt-1 text-sm text-red-500">{error}</p>
        )}
      </div>
    );
  }
);

Dropdown.displayName = "Dropdown";

export { Dropdown };
