import React from 'react';
import { Link, useLocation } from 'wouter';
import { cn } from '@/lib/utils';
import { 
  Home,
  Building2,
  Clipboard,
  Camera,
  User,
  LogOut
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuthStore } from '@/store/authStore';

interface MobileLayoutProps {
  children: React.ReactNode;
}

const MobileLayout = ({ children }: MobileLayoutProps) => {
  const [location] = useLocation();
  const { user, logout } = useAuthStore();
  
  // Define navigation items based on user role
  const navigationItems = user?.role === 'contractor' 
    ? [
        { icon: Home, label: 'Home', path: '/contractor' },
        { icon: Clipboard, label: 'Projects', path: '/projects' },
        { icon: User, label: 'Profile', path: '/profile' },
      ]
    : [
        { icon: Home, label: 'Home', path: '/' },
        { icon: Building2, label: 'Buildings', path: '/buildings' },
        { icon: Camera, label: 'Inspect', path: '/inspect' },
        { icon: User, label: 'Profile', path: '/profile' },
      ];

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Top Header */}
      <header className="bg-white shadow-sm px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-md bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
            <Building2 className="h-5 w-5 text-white" />
          </div>
          <h1 className="text-lg font-semibold bg-gradient-to-r from-blue-700 to-blue-500 bg-clip-text text-transparent">
            BuildInspect
          </h1>
        </div>
        
        {user && (
          <button 
            onClick={() => logout()}
            className="p-2 text-gray-500 hover:text-red-500 transition-colors"
          >
            <LogOut className="h-5 w-5" />
          </button>
        )}
      </header>
      
      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          transition={{ duration: 0.3 }}
          className="container mx-auto px-4 py-6 max-w-md"
        >
          {children}
        </motion.div>
      </main>
      
      {/* Bottom Navigation */}
      {user && (
        <nav className="bg-white shadow-[0_-2px_10px_rgba(0,0,0,0.05)] py-2">
          <ul className="flex justify-around">
            {navigationItems.map((item) => {
              const isActive = location === item.path;
              return (
                <li key={item.path}>
                  <Link href={item.path}>
                    <a className="flex flex-col items-center p-2">
                      <item.icon 
                        className={cn(
                          "h-6 w-6 mb-1",
                          isActive ? "text-blue-600" : "text-gray-500"
                        )} 
                      />
                      <span 
                        className={cn(
                          "text-xs",
                          isActive ? "text-blue-600 font-medium" : "text-gray-500"
                        )}
                      >
                        {item.label}
                      </span>
                    </a>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      )}
    </div>
  );
};

export default MobileLayout;