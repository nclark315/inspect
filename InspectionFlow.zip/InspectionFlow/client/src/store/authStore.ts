import { create } from 'zustand';
import { apiRequest } from '@/lib/queryClient';

interface User {
  id: number;
  username: string;
  role: 'inspector' | 'contractor' | 'admin';
  name: string;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>()((set) => ({
  user: null,
  isAuthenticated: false,
  isLoading: false,
  error: null,
  
  login: async (username: string, password: string) => {
    try {
      set({ isLoading: true, error: null });
      
      const response = await apiRequest(
        'POST',
        '/api/auth/login',
        { username, password }
      );
      
      try {
        const data = await response.json();
        
        set({
          user: data.user,
          isAuthenticated: true,
          isLoading: false,
          error: null,
        });
      } catch (error) {
        console.error('Error parsing response:', error);
        set({
          isLoading: false,
          error: 'Login failed. Please try again.',
        });
      }
    } catch (error) {
      set({
        isLoading: false,
        error: error instanceof Error ? error.message : 'Login failed. Please try again.',
      });
    }
  },
  
  logout: async () => {
    try {
      await apiRequest(
        'POST',
        '/api/auth/logout'
      );
      
      set({
        user: null,
        isAuthenticated: false,
        error: null,
      });
    } catch (error) {
      console.error('Logout error:', error);
    }
  },
  
  clearError: () => set({ error: null }),
}));