import { create } from 'zustand';
import { Photo } from '@/lib/types';

interface InspectionState {
  currentStep: number;
  selectedBuilding: string;
  selectedCategory: string;
  selectedComponent: string;
  uploadedPhotos: Photo[];
  notes: string;
  
  // Actions
  setCurrentStep: (step: number) => void;
  setSelectedBuilding: (building: string) => void;
  setSelectedCategory: (category: string) => void;
  setSelectedComponent: (component: string) => void;
  addUploadedPhoto: (photo: Photo) => void;
  removeUploadedPhoto: (photoId: string) => void;
  clearUploadedPhotos: () => void;
  setNotes: (notes: string) => void;
  reset: () => void;
}

export const useInspectionStore = create<InspectionState>()(
  (set) => ({
    currentStep: 1,
    selectedBuilding: '',
    selectedCategory: '',
    selectedComponent: '',
    uploadedPhotos: [],
    notes: '',
    
    setCurrentStep: (step: number) => set(() => ({ currentStep: step })),
    
    setSelectedBuilding: (building: string) => 
      set(() => ({ 
        selectedBuilding: building,
        currentStep: 2 
      })),
    
    setSelectedCategory: (category: string) => 
      set(() => ({ 
        selectedCategory: category,
        currentStep: 3 
      })),
    
    setSelectedComponent: (component: string) => 
      set(() => ({ 
        selectedComponent: component,
        currentStep: 4
      })),
    
    addUploadedPhoto: (photo: Photo) => 
      set((state) => ({ 
        uploadedPhotos: [...state.uploadedPhotos, photo] 
      })),
    
    removeUploadedPhoto: (photoId: string) => 
      set((state) => ({ 
        uploadedPhotos: state.uploadedPhotos.filter(photo => photo.id !== photoId) 
      })),
    
    clearUploadedPhotos: () => set(() => ({ uploadedPhotos: [] })),
    
    setNotes: (notes: string) => set(() => ({ notes })),
    
    reset: () => set(() => ({
      currentStep: 1,
      selectedBuilding: '',
      selectedCategory: '',
      selectedComponent: '',
      uploadedPhotos: [],
      notes: '',
    })),
  })
);